__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/4e76cc3a636845a2.js",
  "static/chunks/turbopack-5b81cff1fb499cac.js"
])
