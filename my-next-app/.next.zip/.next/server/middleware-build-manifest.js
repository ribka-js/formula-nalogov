globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/4e76cc3a636845a2.js",
      "static/chunks/turbopack-5b81cff1fb499cac.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/4e76cc3a636845a2.js",
      "static/chunks/turbopack-2c3f1d41a57f0e5f.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/2e175d805581124f.js",
    "static/chunks/47f477e3d2ef265b.js",
    "static/chunks/c19da6693934fea1.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/turbopack-467582edee172093.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];